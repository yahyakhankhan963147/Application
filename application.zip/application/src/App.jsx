import React, { useState } from "react";
import DOMPurify from "dompurify";

const App = () => {
  const [articleContent, setArticleContent] = useState(null);
  const [error, setError] = useState(null);
  const [url, setUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleDownload = async () => {
    setError(null);
    setArticleContent(null);
    setIsLoading(true);

    try {
      const response = await fetch(
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`
      );
      if (!response.ok) {
        if (response.status === 403) {
          throw new Error("Access to this website is forbidden (403).");
        } else {
          throw new Error(
            `Network response was not ok (status: ${response.status})`
          );
        }
      }
      const html = await response.text();
      setArticleContent(DOMPurify.sanitize(html)); // Sanitize the HTML
    } catch (err) {
      console.error("Error fetching article:", err);
      setError(err.toString());
    } finally {
      setIsLoading(false);
    }
  };

  // Function to download PDFs
  const downloadPDF = (pdfUrl, fileName) => {
    const link = document.createElement("a");
    link.href = pdfUrl;
    link.download = fileName || "download.pdf";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Internal CSS Styles
  const styles = {
    container: {
      maxWidth: "800px",
      margin: "0 auto",
      padding: "20px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f5f5f5",
    },
    title: {
      textAlign: "center",
      color: "#333",
      marginBottom: "20px",
    },
    inputCard: {
      background: "#fff",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
      display: "flex",
      gap: "10px",
      marginBottom: "20px",
    },
    urlInput: {
      flex: 1,
      padding: "10px",
      border: "1px solid #ddd",
      borderRadius: "4px",
      fontSize: "16px",
    },
    downloadButton: {
      padding: "10px 20px",
      backgroundColor: "#007bff",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      fontSize: "16px",
    },
    downloadButtonDisabled: {
      backgroundColor: "#ccc",
      cursor: "not-allowed",
    },
    errorMessage: {
      color: "#ff0000",
      textAlign: "center",
      marginTop: "20px",
    },
    instruction: {
      textAlign: "center",
      color: "#666",
      marginTop: "20px",
    },
    loadingSpinner: {
      textAlign: "center",
      marginTop: "20px",
      fontSize: "18px",
      color: "#007bff",
    },
    contentContainer: {
      background: "#fff",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
      marginTop: "20px",
    },
    contentTitle: {
      color: "#333",
      marginBottom: "20px",
    },
    content: {
      lineHeight: "1.6",
      color: "#333",
    },
    contentImg: {
      maxWidth: "100%",
      height: "auto",
      borderRadius: "4px",
    },
    contentLink: {
      color: "#007bff",
      textDecoration: "none",
    },
    contentLinkHover: {
      textDecoration: "underline",
    },
    pdfButton: {
      marginTop: "10px",
      padding: "8px 16px",
      backgroundColor: "#28a745",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Webpage Downloader</h1>
      <div style={styles.inputCard}>
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL (e.g., https://www.nature.com/articles/nm.3435)"
          style={styles.urlInput}
        />
        <button
          onClick={handleDownload}
          style={
            isLoading
              ? { ...styles.downloadButton, ...styles.downloadButtonDisabled }
              : styles.downloadButton
          }
          disabled={isLoading}
        >
          {isLoading ? "Downloading..." : "Download"}
        </button>
      </div>

      {error && <div style={styles.errorMessage}>Error: {error}</div>}
      {!articleContent && !error && !isLoading && (
        <div style={styles.instruction}>
          Enter a URL and click "Download" to see the content.
        </div>
      )}
      {isLoading && <div style={styles.loadingSpinner}>Loading...</div>}
      {articleContent && (
        <div style={styles.contentContainer}>
          <h2 style={styles.contentTitle}>Downloaded Content:</h2>
          <div
            style={styles.content}
            dangerouslySetInnerHTML={{ __html: articleContent }}
          />
          {/* PDF Download Button */}
          {articleContent.includes(".pdf") && (
            <button
              style={styles.pdfButton}
              onClick={() => {
                const pdfUrl =
                  articleContent.match(/href="([^"]*\.pdf)"/i)?.[1];
                if (pdfUrl) {
                  downloadPDF(pdfUrl, "downloaded-file.pdf");
                }
              }}
            >
              Download PDF
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default App;
